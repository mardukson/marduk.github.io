bg="#FFFFFF"
fg="black"
fs=11
ff='"Verdana","Arial"'

emphFg="DarkGreen"
topFg="black"
topFf="times"
topFs=15
inputFg="black"

thBg="#87C687"
thFg="white"
dlgFg="black"

thMidBg="white"
thMidFg="black"

buttonFg="white"

tipBg="#C4FCE2"
tipBd="DarkGreen"
lnk="DarkGreen"
lnkA="#9FFFD1"
lnkV="#02BA9E"
baseFg="white"
baseFf=ff
baseFs=10

gui=g=new Object()

g.minw=0
g.minh=0
g.lm=10
g.rm=10

g.bgcolor="#A7C3F4"

g.nextprevfg="#000000"
g.nextprevfs=12
g.nextprevoutfg="#6DA683"
g.nextprevoutfs=12
g.gripfg="#000000"
g.gripfs=10
g.infofg="#C9E2FF"
g.infofs=11
g.preloadfg="#5672A3"
g.preloadfs=10
g.toolbarfg="#5672A3"
g.toolbarfs=11

g.fill=t=new Object
t.ch=26
t.bh=14
t.lcb=0
t.rcb=0
t.mlcb=0
t.mrcb=0

g.anim=t=new Object()
t.h=27
t.sc="#000000"
t.sw=1

g.imgs=new Array

g.ceil=t=new Object
t.bgcolor="#A7C3F4"
t.h=53

g.bgceil=t=new Object
t.dy=0
t.t=2
t.h=19
t.dx=90
t.lw=23
t.rw=23

g.ktop=t=new Object
t.dx=0
t.dy=19
t.h=32
t.lw=15
t.mw=15
t.rw=15

g.logo=t=new Object
t.t=3
t.margin=0
t.h=10
t.w=60
t.font='"Verdana","Arial"'
t.fontsize=13
t.fg="#9F3515"

g.tabs=t=new Object
t.l=25
t.t=5
t.font='"Verdana","Arial"'
t.fontsize=11
t.textcolor="#000000"
t.stextcolor="#000000"
t.bgcolor="#FBC87E"
t.sbgcolor="#FEEFD7"

g.tab=t=new Object
t.dx=260
t.h=16
t.txtt=1
t.lw=3
t.rw=6

g.titles=t=new Object
t.t=32
t.h=18
t.margin=10

g.bgmid=t=new Object
t.dx=0
t.lw=8
t.rw=8

g.kmid=t=new Object
t.dx=17
t.lw=15
t.mw=15
t.rw=15

g.base=t=new Object
t.bgcolor="#A7C3F4"
t.h=65

g.bgbase=t=new Object
t.t=22
t.dy=67
t.h=85
t.dx=136
t.lw=38
t.rw=38

g.kbot=t=new Object
t.dx=45
t.dy=45
t.h=23
t.lw=15
t.mw=15
t.rw=15

g.prev=t=new Object
t.t=25
t.h=16
t.dx=212
t.dy=168
t.lw=17
t.rw=7
t.txtt=0
t.bmargin=15

g.next=t=new Object
t.t=25
t.h=16
t.dx=236
t.dy=168
t.lw=7
t.rw=17
t.txtt=0
t.bmargin=15

g.bgslider=t=new Object
t.t=19
t.dx=269
t.dy=184
t.h=24
t.lw=35
t.rw=35
t.margin=0

g.grip=t=new Object
t.t=5
t.dx=339
t.dy=234
t.h=13
t.w=80
t.lw=9
t.rw=8
t.txtt=0

g.bginfo=t=new Object
t.dx=-1
t.dy=-1
t.t=45
t.h=13
t.lw=0
t.rw=0
t.margin=10
t.txtt=1

g.bgpreload=t=new Object
t.dx=356
t.dy=208
t.t=45
t.h=15
t.lw=11
t.rw=6
t.margin=10
t.txtt=1

g.preload=t=new Object
t.dx=373
t.dy=223
t.h=11
t.t=2
t.lpw=13
t.lcw=13
t.rw=8
t.txtt=-1

g.btntoolbar=t=new Object
t.h=13
t.w=80
t.t=51
t.l=15
t.dx=407
t.dy=247
t.lvw=19	
t.lhw=19
t.rw=13
t.txtt=0

g.bgtools=t=new Object
t.h=38
t.t=63
t.l=15
t.dx=458
t.dy=260
t.lw=20
t.rw=14

g.toolbar=t= new Object
t.h=44
t.t=68
t.lmargin=25
t.rmargin=25
t.margin=1
t.itspacing=2
t.icspacing=2
t.txtt=5
t.l3D="#93ACD7"
t.d3D="#000000"
t.imgw=50
t.imgh=25

g.toolbar.btn_pagemode=t=new Object
t.imgw=40
t.ox1=200
t.ox2=240

g.toolbar.btn_toc=t=new Object
t.imgw=35
t.ox1=280

g.toolbar.btn_slideshow=t=new Object
t.imgw=45
t.ox1=315
t.ox2=360

g.toolbar.btn_find=t=new Object
t.imgw=30
t.ox1=405

g.toolbar.btn_prefs=t=new Object
t.imgw=32
t.ox1=435

g.toolbar.btn_print=t=new Object
t.imgw=30
t.ox1=467



g.imgframe=t=new Object
t.lw=7
t.rw=8
t.th=6
t.bh=10

g.notile=t=new Object
t.w=492
t.h=102

g.htile=t=new Object
t.w=38
t.h=298

g.vtile=t=new Object
t.w=62	
t.h=18

g.menucorners=t=new Object
t.w=434
t.h=25