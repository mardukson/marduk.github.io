
var _PartnerName = null;
var _NbTocBanners = 0;
var _TocBannersDelay = 0;
var _FitTocBanners = true;


