var _lab2=new Array
_lab2.multdoc="Multimedia Document"
_lab2.multdocname="Name:"
_lab2.multdoctype="Type:"
_lab2.multdocplay="Play!"
_lab2.multdocexplain="You need to launch an external player to play this document. <span class='EmphasisBold'>Click the button below</span> to launch the player."

	
