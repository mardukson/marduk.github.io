var _lab=new Object
_lab.Title="KeeBook Print"
_lab.Ok="OK"
_lab.Print="Print"
_lab.Acrobat="Printer configuration"
_lab.AcrobatExplanation="To ensure you will be able to print the KeeBook, please obtain the most recent edition of the free <a target='blank' href='http://www.adobe.com/products/acrobat/readstep.html'>Acrobat Reader</a> from the Adobe* Web site."
_lab.AcrobatCheck="Checking your system..."
_lab.AcrobatInstalled="You <B>already have</B> Acrobat Reader (or Acrobat) installed."
_lab.AcrobatNotInstalled="You <B>need</B> to install Acrobat Reader (or the full Acrobat)."