var _lab=new Object;

_lab.common=l=new Object;
l.intro1="This KeeBook (multimedia Web book) was created with <span class=EmphasisBold>KeeBook Creator Home</span>, a software product by KeeBoo Corp."
l.intro2="<span class=EmphasisBold>With KeeBook Creator Home, create stunning 3D Web books!</span>  At home, with your children or friends."
l.pt1="Save the Web worthiest pages."
l.pt2="Collect, organize and comment documents, images, illustrations and all your preferred Web pages."
l.pt3="Create and Send photo albums."
l.pt4="Publish your most beautiful books on your Web site."
l.downl="Visit the KeeBoo Web site now: <span class=EmphasisBold><a href=\"javascript:_ktop.goTo7x('AutorunLink','http://www.keeboo.com');\">http://www.keeboo.com</a></span>"
l.reserved="Edition strictly limited to personal and non-commercial purposes."

_lab.home=l=new Object;
l.intro1="This KeeBook (multimedia Web book) was created with <span class=EmphasisBold>KeeBook Creator Home</span>, a software product by KeeBoo Corp."
l.intro2="<span class=EmphasisBold>With KeeBook Creator Home, create stunning 3D Web books!</span>  At home, with your children or friends."
l.pt1="Save the Web worthiest pages."
l.pt2="Collect, organize and comment documents, images, illustrations and all your preferred Web pages."
l.pt3="Create and Send photo albums."
l.pt4="Publish your most beautiful books on your Web site."
l.downl="Visit the KeeBoo Web site now: <span class=EmphasisBold><a href=\"javascript:_ktop.goTo7x('AutorunLink','http://www.keeboo.com');\">http://www.keeboo.com</a></span>"
l.reserved="Edition strictly limited to personal and non-commercial purposes."

_lab.educ=l=new Object;
l.intro1="This KeeBook (multimedia Web book) was created with <span class=EmphasisBold>KeeBook Creator Education</span>, a software product by KeeBoo Corp."
l.intro2="<span class=EmphasisBold>KeeBook Creator Education, a virtual authoring tool for teaching.</span> At school, university or in the lab."
l.pt1="Gather, store and organize all types of electronic documents."
l.pt2="Create workbooks of your teaching majors."
l.pt3="Speed-up your Web quests and enhance them with personal annotations."
l.pt4="Publish your students' books."
l.downl="Visit the KeeBoo Web site now: <span class=EmphasisBold><a href=\"javascript:_ktop.goTo7x('AutorunLink','http://www.keeboo.com');\">http://www.keeboo.com</a></span>"
l.reserved="Edition strictly reserved for students and teachers, schools, universities and organizations related to K12, secondary or higher education."
 
_lab.pro=l=new Object;
l.intro1="This KeeBook (multimedia Web book) was created with <span class=EmphasisBold>KeeBook Creator Pro</span>, a software product by KeeBoo Corp."
l.intro2="<span class=EmphasisBold>KeeBook Creator Pro:</span> a software to collect, organize, comment, share and present information in KeeBoo books."
l.downl="Visit the KeeBoo Web site now: <span class=EmphasisBold><a href=http://www.keeboo.com target=_blank>http://www.keeboo.com</a></span>"
l.reserved="Edition for professional use."

_lab.publishing=l=new Object;
l.intro1="This KeeBook (multimedia Web book) was created with <span class=EmphasisBold>KeeBook Publishing</span>, a product by KeeBoo Corp."
l.intro2="<span class=EmphasisBold>KeeBook Publishing:</span> a product to collect, organize, comment, share and present information in KeeBoo books."
l.downl="Visit the KeeBoo Web site now: <span class=EmphasisBold><a href=http://www.keeboo.com target=_blank>http://www.keeboo.com</a></span>"
l.reserved="Edition for professional use."