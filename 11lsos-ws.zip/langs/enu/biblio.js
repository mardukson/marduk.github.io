var _lab=new Object;
_lab.biblioExplain="<span class=EmphasisBold>%1</span> is very concerned with copyright issues. For this reason, this page provides more information about each document enclosed in this KeeBook.<BR>You will find listed below: a link to each Web page's original site, the corresponding page number and title in the KeeBook, and a link to the original page (when it is hosted on another site)."
_lab.original="(original page)"
_lab.page="Page"