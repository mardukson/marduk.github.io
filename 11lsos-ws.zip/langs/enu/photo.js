var _lab=new Object;

// No entities here
_lab.photoTip="Click to view the image in full size"
_lab.closeTip="Click to close this window"
