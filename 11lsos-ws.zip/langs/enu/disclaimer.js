var _lab=new Object;
_lab.cancel = "OK"
_lab.about = "About"
_lab.disclaimer = "Disclaimer"
_lab.windowTitle = "About KeeBook"

_lab.aboutTitle = "About KeeBook�"
_lab.engineVersion = "Engine Version:"
_lab.author = "KeeBook made with:"
_lab.copyright1 = "� 1997-2003 KeeBoo. All rights reserved."
_lab.copyright2 = "KeeBoo, KeeBook, KeeBook Publishing, KeeBook Creator, KeeBook-it, KeeBook Online Library and their respective logos are trademarks or registered trademarks of KeeBoo."
_lab.link = "Powered by KeeBoo.com"

_lab.legalTitle="Legal Statements"
_lab.keeboCreated="This KeeBook was created with <b>%1</b>. <a href=\"javascript:_ktop.goTo7x('AutorunLink','http://www.keeboo.com');\">Click here</a> for more information about the KeeBoo products."
_lab.copyRight="The KeeBook, KeeBook Publishing, KeeBook Creator, KeeBook-it and KeeBook Online Library products shall not be used to distribute any copyrighted content that you do not have the right to use, reproduce or distribute, or to circumvent any mechanism intended to prevent use, modification or copying of proprietary materials."
_lab.limit="Limitation of Liability."
var limit1Keeboo="IN NO EVENT SHALL KeeBoo BE LIABLE "
var limit1Partner="IN NO EVENT SHALL KeeBoo OR %1 BE LIABLE "
var limit2="FOR ANY LOSS OR DAMAGE OF ANY KIND, INCLUDING BUT NOT LIMITED TO INCIDENTAL, INDIRECT, PUNITIVE, EXEMPLARY, CONSEQUENTIAL OR SPECIAL DAMAGES ARISING OUT OF THE INSTALLATION, USE, SUPPORT, EVALUATION OR OPERATION OF THE PRESENT BOOK, WHICH IS EXPLICITLY ACCEPTED BY USER, WHO IS ALSO INFORMED THAT THE DOCUMENTS AND INFORMATION WERE GATHERED, COMMENTED AND EXPOSED IN THIS BOOK BY ITS ORIGINAL SENDER/PUBLISHER AND UNDER ITS SOLE RESPONSIBILITY."
_lab.limitText=limit1Keeboo + limit2
_lab.fullCopy="%1. Copyright &copy; 1997-2002, KeeBoo. All rights reserved. KeeBoo, KeeBook, KeeBook Publishing, KeeBook Creator, KeeBook-it, KeeBook Online Library and their logos are trademarks or registered trademarks of KeeBoo."
