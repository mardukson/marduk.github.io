var _lab=new Object
_lab.title="KeeBook Options"
_lab.lang="Language of KeeBook interface:"
_lab.anim="Show 3-D page flipping effect"
_lab.delay="During slide show, change pages every"
_lab.seconds="seconds"
_lab.OK="&nbsp;OK&nbsp;"
_lab.Cancel="Cancel"