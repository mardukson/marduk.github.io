var _lab=new Object;
_lab.index="Index"
_lab.indexFind="Find:"
_lab.indexStart="Start"
_lab.indexStop="Stop"
_lab.indexClear="Clear"
_lab.indexExtOnePage="This book includes one external page (i.e. a page that is referenced on remote Web sites).&nbsp;"
_lab.indexExtSevPages="This book includes %1 external pages (i.e. pages that are referenced on remote Web sites).&nbsp;"
_lab.indexExtExplanation="Only the titles of external pages will be searched, not the pages themselves."
_lab.findIn="In"
_lab.findDoc="Documents"
_lab.findTit="Titles"
_lab.findCountOnePage="%1 page found"
_lab.findCountSevPages="%1 pages found"
_lab.indexClose="Close"

// No entities below
_lab.findCheck="Please specify if you want to search in Titles and/or Documents by checking the associated box."
_lab.findStr="Please enter the text you want to find."
